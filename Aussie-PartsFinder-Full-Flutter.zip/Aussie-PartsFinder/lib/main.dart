import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const AussiePartsFinderApp());
}

class AussiePartsFinderApp extends StatelessWidget {
  const AussiePartsFinderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Aussie PartsFinder',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0B6E4F)),
        useMaterial3: true,
      ),
      home: const PartsFinderHome(),
    );
  }
}

class Marketplace {
  final String name;
  final String category;
  final String Function(String query) buildUrl;
  final String note;

  const Marketplace({
    required this.name,
    required this.category,
    required this.buildUrl,
    this.note = '',
  });
}

class PartsFinderHome extends StatefulWidget {
  const PartsFinderHome({super.key});

  @override
  State<PartsFinderHome> createState() => _PartsFinderHomeState();
}

class _PartsFinderHomeState extends State<PartsFinderHome> {
  final _vin = TextEditingController();
  final _plate = TextEditingController();
  final _year = TextEditingController();
  final _make = TextEditingController();
  final _model = TextEditingController();
  final _part = TextEditingController();
  final _partNumber = TextEditingController();

  String _vehicleType = 'Car / 4WD';
  String _condition = 'All';
  String _state = 'QLD';
  bool _decodingVin = false;
  String? _vinStatus;

  static const vehicleTypes = [
    'Car / 4WD',
    'Motorcycle',
    'Truck',
    'Boat / Marine',
  ];

  static const conditions = ['All', 'New', 'Used'];

  static const states = [
    'QLD',
    'NSW',
    'VIC',
    'SA',
    'WA',
    'TAS',
    'ACT',
    'NT',
  ];

  final List<Marketplace> _marketplaces = [
    Marketplace(
      name: 'eBay Australia',
      category: 'Marketplace',
      buildUrl: (q) => 'https://www.ebay.com.au/sch/i.html?_nkw=${Uri.encodeQueryComponent(q)}',
    ),
    Marketplace(
      name: 'Gumtree Australia',
      category: 'Marketplace',
      buildUrl: (q) => 'https://www.gumtree.com.au/s-${Uri.encodeQueryComponent(q)}/k0',
    ),
    Marketplace(
      name: 'Facebook Marketplace',
      category: 'Marketplace',
      buildUrl: (q) => 'https://www.facebook.com/marketplace/search/?query=${Uri.encodeQueryComponent(q)}',
      note: 'Facebook login may be required.',
    ),
    Marketplace(
      name: 'Amazon Australia',
      category: 'Marketplace',
      buildUrl: (q) => 'https://www.amazon.com.au/s?k=${Uri.encodeQueryComponent(q)}',
    ),
    Marketplace(
      name: 'AliExpress',
      category: 'Marketplace',
      buildUrl: (q) => 'https://www.aliexpress.com/wholesale?SearchText=${Uri.encodeQueryComponent(q)}',
    ),
    Marketplace(
      name: 'Repco',
      category: 'Auto retailer',
      buildUrl: (q) => 'https://www.google.com/search?q=${Uri.encodeQueryComponent("site:repco.com.au $q")}',
    ),
    Marketplace(
      name: 'Supercheap Auto',
      category: 'Auto retailer',
      buildUrl: (q) => 'https://www.google.com/search?q=${Uri.encodeQueryComponent("site:supercheapauto.com.au $q")}',
    ),
    Marketplace(
      name: 'Autobarn',
      category: 'Auto retailer',
      buildUrl: (q) => 'https://www.google.com/search?q=${Uri.encodeQueryComponent("site:autobarn.com.au $q")}',
    ),
    Marketplace(
      name: 'Sparesbox',
      category: 'Auto retailer',
      buildUrl: (q) => 'https://www.google.com/search?q=${Uri.encodeQueryComponent("site:sparesbox.com.au $q")}',
    ),
    Marketplace(
      name: 'Burson Auto Parts',
      category: 'Auto retailer',
      buildUrl: (q) => 'https://www.google.com/search?q=${Uri.encodeQueryComponent("site:burson.com.au $q")}',
    ),
    Marketplace(
      name: 'Amayama',
      category: 'OEM / import',
      buildUrl: (q) => 'https://www.google.com/search?q=${Uri.encodeQueryComponent("site:amayama.com $q")}',
    ),
    Marketplace(
      name: 'Partsouq',
      category: 'OEM / import',
      buildUrl: (q) => 'https://www.google.com/search?q=${Uri.encodeQueryComponent("site:partsouq.com $q")}',
    ),
    Marketplace(
      name: 'Partzilla',
      category: 'Motorcycle / powersports',
      buildUrl: (q) => 'https://www.google.com/search?q=${Uri.encodeQueryComponent("site:partzilla.com $q")}',
    ),
    Marketplace(
      name: 'Boats.net',
      category: 'Marine',
      buildUrl: (q) => 'https://www.google.com/search?q=${Uri.encodeQueryComponent("site:boats.net $q")}',
    ),
    Marketplace(
      name: 'Marine Deals Australia',
      category: 'Marine',
      buildUrl: (q) => 'https://www.google.com/search?q=${Uri.encodeQueryComponent("site:marinedeals.com.au $q")}',
    ),
    Marketplace(
      name: 'Truck Parts Australia web search',
      category: 'Truck',
      buildUrl: (q) => 'https://www.google.com/search?q=${Uri.encodeQueryComponent("Australia truck parts wreckers $q")}',
    ),
    Marketplace(
      name: 'Australian Wreckers web search',
      category: 'Used / wreckers',
      buildUrl: (q) => 'https://www.google.com/search?q=${Uri.encodeQueryComponent("Australia wreckers used parts $q")}',
    ),
    Marketplace(
      name: 'Google Shopping / Web',
      category: 'Universal',
      buildUrl: (q) => 'https://www.google.com/search?q=${Uri.encodeQueryComponent(q + " buy Australia")}',
    ),
  ];

  @override
  void dispose() {
    for (final c in [_vin, _plate, _year, _make, _model, _part, _partNumber]) {
      c.dispose();
    }
    super.dispose();
  }

  String get _searchQuery {
    final bits = <String>[
      if (_year.text.trim().isNotEmpty) _year.text.trim(),
      if (_make.text.trim().isNotEmpty) _make.text.trim(),
      if (_model.text.trim().isNotEmpty) _model.text.trim(),
      if (_part.text.trim().isNotEmpty) _part.text.trim(),
      if (_partNumber.text.trim().isNotEmpty) _partNumber.text.trim(),
      if (_condition != 'All') _condition,
    ];
    return bits.join(' ');
  }

  Future<void> _launch(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not open $url')),
      );
    }
  }

  Future<void> _decodeVin() async {
    final vin = _vin.text.trim().toUpperCase();
    if (vin.length != 17) {
      setState(() => _vinStatus = 'A VIN should normally contain 17 characters.');
      return;
    }

    setState(() {
      _decodingVin = true;
      _vinStatus = null;
    });

    try {
      final uri = Uri.parse(
        'https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVinValuesExtended/'
        '${Uri.encodeComponent(vin)}?format=json',
      );
      final response = await http.get(uri).timeout(const Duration(seconds: 15));
      if (response.statusCode != 200) {
        throw Exception('VIN service returned ${response.statusCode}');
      }

      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final results = (data['Results'] as List?) ?? [];
      if (results.isEmpty) throw Exception('No VIN result found');

      final item = Map<String, dynamic>.from(results.first as Map);
      final make = (item['Make'] ?? '').toString().trim();
      final model = (item['Model'] ?? '').toString().trim();
      final year = (item['ModelYear'] ?? '').toString().trim();
      final vehicleType = (item['VehicleType'] ?? '').toString().toLowerCase();

      setState(() {
        if (make.isNotEmpty) _make.text = make;
        if (model.isNotEmpty) _model.text = model;
        if (year.isNotEmpty) _year.text = year;

        if (vehicleType.contains('motorcycle')) {
          _vehicleType = 'Motorcycle';
        } else if (vehicleType.contains('truck')) {
          _vehicleType = 'Truck';
        } else if (vehicleType.contains('car') ||
            vehicleType.contains('utility') ||
            vehicleType.contains('wagon') ||
            vehicleType.contains('multipurpose')) {
          _vehicleType = 'Car / 4WD';
        }

        _vinStatus = (make.isEmpty && model.isEmpty && year.isEmpty)
            ? 'VIN was checked, but vehicle details were limited. Enter them manually.'
            : 'VIN decoded: $year $make $model'.trim();
      });
    } catch (e) {
      setState(() {
        _vinStatus =
            'VIN decoding could not complete. You can still enter the vehicle manually.';
      });
    } finally {
      if (mounted) setState(() => _decodingVin = false);
    }
  }

  String _officialRegoUrl() {
    switch (_state) {
      case 'QLD':
        return 'https://www.service.transport.qld.gov.au/checkrego/public/Welcome.xhtml';
      case 'NSW':
        return 'https://check-registration.service.nsw.gov.au/';
      case 'VIC':
        return 'https://www.vicroads.vic.gov.au/registration/buy-sell-or-transfer-a-vehicle/check-vehicle-registration';
      case 'SA':
        return 'https://account.ezyreg.sa.gov.au/account/check-registration.htm';
      case 'WA':
        return 'https://online.transport.wa.gov.au/webExternal/registration/';
      case 'TAS':
        return 'https://www.service.tas.gov.au/services/transport/vehicle-registration/check-your-registration-status';
      case 'ACT':
        return 'https://rego.act.gov.au/regosoawicket/public/reg/FindRegistrationPage';
      case 'NT':
        return 'https://nt.gov.au/driving/rego/check-your-registration-and-expiry-date';
      default:
        return 'https://www.google.com/search?q=Australian+rego+check';
    }
  }

  Future<void> _searchAll() async {
    final q = _searchQuery;
    if (q.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter a part, part number or vehicle first.')),
      );
      return;
    }

    final combined = Uri.encodeQueryComponent(
      '$q Australia parts new used ${_vehicleType.toLowerCase()}',
    );
    await _launch('https://www.google.com/search?q=$combined');
  }

  void _clear() {
    setState(() {
      for (final c in [_vin, _plate, _year, _make, _model, _part, _partNumber]) {
        c.clear();
      }
      _vehicleType = 'Car / 4WD';
      _condition = 'All';
      _state = 'QLD';
      _vinStatus = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final query = _searchQuery;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Aussie PartsFinder'),
        actions: [
          IconButton(
            onPressed: _clear,
            tooltip: 'Clear',
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Find vehicle parts across Australia',
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Cars, 4WDs, motorcycles, trucks and boats. Search new and used parts across marketplaces, retailers, OEM suppliers and wreckers.',
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: _vehicleType,
                    decoration: const InputDecoration(
                      labelText: 'Vehicle type',
                      border: OutlineInputBorder(),
                    ),
                    items: vehicleTypes
                        .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                        .toList(),
                    onChanged: (v) => setState(() => _vehicleType = v!),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          ExpansionTile(
            initiallyExpanded: true,
            title: const Text('VIN search'),
            subtitle: const Text('Decode a 17-character VIN and fill vehicle details'),
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: Column(
                  children: [
                    TextField(
                      controller: _vin,
                      textCapitalization: TextCapitalization.characters,
                      decoration: const InputDecoration(
                        labelText: 'VIN',
                        hintText: '17-character VIN',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: _decodingVin ? null : _decodeVin,
                        icon: _decodingVin
                            ? const SizedBox.square(
                                dimension: 18,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.qr_code_scanner),
                        label: Text(_decodingVin ? 'Checking VIN...' : 'Decode VIN'),
                      ),
                    ),
                    if (_vinStatus != null) ...[
                      const SizedBox(height: 8),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(_vinStatus!),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),

          ExpansionTile(
            title: const Text('Number plate / rego search'),
            subtitle: const Text('Open your state’s official registration checker'),
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: DropdownButtonFormField<String>(
                            value: _state,
                            decoration: const InputDecoration(
                              labelText: 'State',
                              border: OutlineInputBorder(),
                            ),
                            items: states
                                .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                                .toList(),
                            onChanged: (v) => setState(() => _state = v!),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          flex: 3,
                          child: TextField(
                            controller: _plate,
                            textCapitalization: TextCapitalization.characters,
                            decoration: const InputDecoration(
                              labelText: 'Number plate',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: () => _launch(_officialRegoUrl()),
                        icon: const Icon(Icons.open_in_new),
                        label: Text('Open official $_state rego checker'),
                      ),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'Australian state registration systems do not provide one universal public API for automatic plate-to-vehicle lookup. This app links to the official checker instead.',
                      style: TextStyle(fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 8),
          Text('Vehicle & part details', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _year,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Year',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: _make,
                  decoration: const InputDecoration(
                    labelText: 'Make',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _model,
            decoration: const InputDecoration(
              labelText: 'Model',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _part,
            decoration: const InputDecoration(
              labelText: 'Part wanted',
              hintText: 'e.g. rear brake master cylinder',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _partNumber,
            decoration: const InputDecoration(
              labelText: 'Part / OEM number (optional)',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: _condition,
            decoration: const InputDecoration(
              labelText: 'Condition',
              border: OutlineInputBorder(),
            ),
            items: conditions
                .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                .toList(),
            onChanged: (v) => setState(() => _condition = v!),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _searchAll,
              icon: const Icon(Icons.travel_explore),
              label: const Text('Search the web for this part'),
            ),
          ),

          const SizedBox(height: 22),
          Text('Search marketplaces & suppliers', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 6),
          Text(
            query.isEmpty
                ? 'Enter vehicle/part details above, then tap a supplier.'
                : 'Searching for: $query',
          ),
          const SizedBox(height: 8),

          ..._marketplaces.map(
            (m) => Card(
              child: ListTile(
                leading: const Icon(Icons.storefront),
                title: Text(m.name),
                subtitle: Text(
                  m.note.isEmpty ? m.category : '${m.category} • ${m.note}',
                ),
                trailing: const Icon(Icons.open_in_new),
                onTap: query.isEmpty ? null : () => _launch(m.buildUrl(query)),
              ),
            ),
          ),

          const SizedBox(height: 18),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Important: Aussie PartsFinder is a search launcher/aggregator. It does not claim to search every listing in real time and does not scrape protected marketplaces. Some sites require login, may change their search links, or may need official/commercial APIs for deeper integration. This design keeps the app legal and maintainable while still giving users one place to search many sources.',
              ),
            ),
          ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }
}
