# Aussie PartsFinder

Australian-first Flutter app for finding new and used vehicle parts.

## Vehicles
- Cars / 4WDs
- Motorcycles
- Trucks
- Boats / marine

## Features in this starter
- Year, make, model search
- Part description search
- OEM / part-number search
- New / used filter
- VIN decoding using the public NHTSA vPIC decoder
- Australian state/territory official rego-check links
- Search launchers for major marketplaces, parts retailers, OEM suppliers, wreckers and broad web search
- Android GitHub Actions workflow that produces APK and AAB artifacts

## Important limitations
No legitimate app can guarantee that it searches **every** marketplace and every live listing without agreements/APIs from those services.

Some marketplaces:
- require login,
- block scraping,
- change search URLs,
- do not expose a public stock API.

Australian number-plate systems also do not provide one universal public plate-to-vehicle API. The app therefore links to official state/territory registration checkers. A future commercial integration can automate this where an approved API is available.

## GitHub phone workflow
1. Extract this ZIP on your Android phone.
2. In your GitHub repository choose **Add file > Upload files**.
3. Upload the **contents of the extracted folder**.
4. Commit to `main`.
5. Open the repository **Actions** tab.
6. Open **Build Android**.
7. When the workflow finishes, download the APK or AAB artifact.

## Google Play
For testing, the project can build with temporary debug signing. Before Play Store publishing, create a proper upload keystore and configure release signing. Never commit the keystore password or private key to a public repository.

## Package
`com.aussiepartsfinder.app`
