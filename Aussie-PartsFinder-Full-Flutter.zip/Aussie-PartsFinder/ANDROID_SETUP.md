# Android build notes

The included GitHub Actions workflow is the easiest build route from an Android phone.

After pushing the files to GitHub:
1. Open **Actions**.
2. Select **Build Android**.
3. Run the workflow if it did not start automatically.
4. Wait for a green check.
5. Open the completed run and download:
   - `Aussie-PartsFinder-APK` for direct Android installation/testing.
   - `Aussie-PartsFinder-AAB` for Google Play preparation.

Before public Play Store release, configure a private upload keystore and release signing.
